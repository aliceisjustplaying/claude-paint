# Bare painter historical-globals control

Upstream main `b4f9c4ebb7428eda1737f46c9ae1db8add6b40c3`, with only the test-only palette-look compile repair in `compile-repair.patch`. No port code was present; no protected path was changed.

The exact `api::draw_rag::tests::an_older_log_sees_the_globals_it_saw` test reproduces the bare painter failure: 1 test selected, exit101 in2.0s, observed `66 / 415863763 / nil`, expected historical replay-build fingerprint `69 / 602616302 / nil`.

Enabling only `finish` makes the exact same test pass: 1 selected test, exit0 in14.1s including10.66s compilation. The three missing names are `varnish`, `cracks` and `relief`, installed by `finish::install` under `cfg(feature = "finish")`. Thus the historical fingerprint test should use that feature gate; a replay-only gate is insufficient for replay-without-finish builds. No expected fingerprint needs changing.

An initial incorrectly qualified filter selected zero tests; that run is not claimed as a pass or proof. Its log and the correcting test-name inventory are retained. The control worktree is removed after recording these results; candidate and untouched baseline remain unchanged.
