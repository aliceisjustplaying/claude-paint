# Updated-main Studio validation

Candidate merge commit `1a3d97dcc29000116038165f32aa192a19d1aceb`, incorporating upstream `ea33747d6fea14055223809f47375b130c6a589e`. All six updated Studio source/test files match the upstream Git blobs exactly; `inputs.json` records their SHA256 and blob IDs. No source edit was made by these checks.

The unchanged machine-wide `scripts/lockrun --timeout 600` ran the sequential batch, which completed with exit0 in71.5s.

- Updated Studio Python: 73 tests passed, exit0 in29.55s (pytest reports29.05s). The approved fixture HOME/TMPDIR command ran against the merged checkout.
- Updated Chrome gallery suite: passed in23.16s across four combinations of API/static and normal/stream views, covering gallery/color/relief selection, persistence, scratch, zoom and fallback behavior.
- Updated Chrome replay suite: 9 named check groups passed in18.54s, with42 exact baseline comparisons and no page errors. The baseline index is the exact `ea33747` Git object. `replay-verification.json` records the named checks and browser-side timings.

Both browser tests launched headless Chrome via the bundled Node/Playwright runtime and used synthetic transports/images. No painting was replayed. Byte-identical copies of the tracked Studio files were used because the replay test writes a report beside itself; only temporary artifacts were written. Runtime paths in public receipts are normalized, and the manifest records actual tool versions, commands, source/log hashes and return codes.
